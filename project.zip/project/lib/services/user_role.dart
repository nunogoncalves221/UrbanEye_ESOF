enum UserRole { citizen, authority }
